// Module definition for the main application module. 
module appstart { 
  // Requires the module appfuncs. 
  requires appfuncs; 
}
